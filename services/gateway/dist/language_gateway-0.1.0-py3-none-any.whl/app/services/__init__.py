"""Gateway service helpers."""
